//
//  FeedsVC.swift
//  G_Feeds
//
//  Created by Azharuddin Mohammad on 07/02/19.
//  Copyright © 2019 NadboyTechnolgiesPvt.Ltd. All rights reserved.
//

import UIKit
import VerticalCardSwiper

class FeedsVC: UIViewController , VerticalCardSwiperDelegate, VerticalCardSwiperDatasource{
    @IBOutlet private var cardSwiper: VerticalCardSwiper!

    
    private var contactsDemoData: [Contact] = [
        Contact(name: "John Doe", age: 33),
        Contact(name: "Chuck Norris", age: 78),
        Contact(name: "Bill Gates", age: 62),
        Contact(name: "Steve Jobs", age: 56),
        Contact(name: "Barack Obama", age: 56),
        Contact(name: "Mila Kunis", age: 34),
        Contact(name: "Pamela Anderson", age: 50),
        Contact(name: "Christina Anguilera", age: 37),
        Contact(name: "Ed Sheeran", age: 23),
        Contact(name: "Jennifer Lopez", age: 45),
        Contact(name: "Nicki Minaj", age: 31),
        Contact(name: "Tim Cook", age: 57),
        Contact(name: "Satya Nadella", age: 50)
    ]

    
    enum JSONError: String,Error {
        case NoData = "ERROR: no data"
        case ConversionFailed = "ERROR: conversion from JSON failed"
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        getFeeds()
        var helloWorldTimer = Timer.scheduledTimer(timeInterval: 300.0, target: self, selector: #selector(self.getFeeds), userInfo: nil, repeats: true)
        
        
        cardSwiper.delegate = self
        cardSwiper.datasource = self
        
        // register cardcell for storyboard use
        cardSwiper.register(nib: UINib(nibName: "ExampleCell", bundle: nil), forCellWithReuseIdentifier: "ExampleCell")
  
    }
  @objc  func getFeeds(){
        let urlPath = "https://newsapi.org/v2/top-headlines?sources=google-news&apiKey=b1cbe92a603e41058bc0b567551343c3"
    guard let endpoint = NSURL(string: urlPath) else {
            print("error occured in endpoint")
            return
        }
        let request = URLRequest(url: endpoint as URL)
        URLSession.shared.dataTask(with: request ) { (data, response, error) in
            do {
                guard let json = try JSONSerialization.jsonObject(with: data!, options:[]) as? NSDictionary else{
                throw JSONError.ConversionFailed
                    
            }
                print(json)
                let data:NSArray = json["articles"] as! NSArray
                print(data)
                for feed in data {
                    print(feed)
                    print("newll")
                }
                
            }
            catch let error as JSONError {
                print(error.rawValue)
            } catch let error as NSError {
                print(error.debugDescription)
            }
        }.resume()
        
    }
    

    func cardForItemAt(verticalCardSwiperView: VerticalCardSwiperView, cardForItemAt index: Int) -> CardCell {
        
        if let cardCell = verticalCardSwiperView.dequeueReusableCell(withReuseIdentifier: "ExampleCell", for: index) as? ExampleCardCell {
            
            let contact = contactsDemoData[index]
            
           // cardCell.setRandomBackgroundColor()
            cardCell.contentView.backgroundColor = UIColor.lightGray
            
            cardCell.nameLbl.text = "Name: " + "asjdjasd asdsdfkj sdfksfldg fdglkfdgkj sdfljsdfk sdkfsljfkd sdfkslkf sdnflsdjf sdfksdklf"//contact.name
            cardCell.ageLbl.text = "Age: \(contact.age ?? 0)"
            
            return cardCell
        }
        return CardCell()
    }
    
    func numberOfCards(verticalCardSwiperView: VerticalCardSwiperView) -> Int {
        return contactsDemoData.count
    }
    
    func willSwipeCardAway(card: CardCell, index: Int, swipeDirection: SwipeDirection) {
        // called right before the card animates off the screen.
        contactsDemoData.remove(at: index)
    }
    
    func didSwipeCardAway(card: CardCell, index: Int, swipeDirection: SwipeDirection) {
        
        // called when a card has animated off screen entirely.
    }

    
   

}
